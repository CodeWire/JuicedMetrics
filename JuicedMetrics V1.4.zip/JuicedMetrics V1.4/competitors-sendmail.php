<h2><img src="<?php echo plugins_url("assets/images/Juiced-Metrics-Green.png", __FILE__);?>" /></h2>

         <hr />

                <h2>Send Report</h2>

            <form action="" method="post" enctype="multipart/form-data">

            <table class="form-table">

            <tbody>

            <tr>

            <th scope="row"><label for="blogname">Email Address :</label></th>

            <td><input type="text" name="email_address" size="31" id="email_address"  class="full-width">
</td>

            </tr>


            </tbody></table>

              

            <p class="submit"><input type="submit" value="Send" class="button button-primary" id="submit" name="submit">

            

            <input name="action" value="sendmail_competitor" type="hidden" />

            </p></form>

                
